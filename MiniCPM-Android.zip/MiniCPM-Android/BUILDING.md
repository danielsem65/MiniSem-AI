# GitHub Actions build

## Fastest path

Create an empty GitHub repository, upload the contents of this project, and push to `main`.

The included workflow:

1. Installs JDK 17 and Android SDK/NDK.
2. Fetches upstream llama.cpp.
3. Records the exact llama.cpp commit used.
4. Builds a CPU-only ARM64 native library with the NDK.
5. Builds debug and release APKs.
6. Uploads both APKs as workflow artifacts.

The debug APK is the easiest one to install directly on a test phone.

## No model is bundled

The APK intentionally does not contain the GGUF model. On first launch use **Pick GGUF** and select the model file from Android Files. The app copies it to private app storage. On later launches, the saved copy is automatically loaded.

This prevents a roughly 650 MB model from becoming part of the APK and lets the same app load other compatible GGUF files.

## Phone requirements

- Android 9/API 28 or newer.
- ARM64 (`arm64-v8a`).
- Enough free storage for the model plus a private copy.
- For a 4 GB RAM phone, start with a small Q4 model and the app's default 2048 context.

## Troubleshooting

### Build fails while fetching llama.cpp

Re-run the workflow. Upstream changes can occasionally break a moving `master` build. For reproducible production builds, replace `LLAMA_CPP_REF: master` in `.github/workflows/android.yml` with a tested llama.cpp commit SHA.

### APK installs but model load fails

Confirm that the selected file is a valid GGUF and matches an architecture supported by the current llama.cpp build. The app validates the GGUF magic before importing it.

### Phone runs out of memory

Use a smaller quantization/model, close other apps, and keep the 2048 context and 256-token output defaults. Increasing context increases KV-cache memory.
