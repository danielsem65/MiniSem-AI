# MiniCPM Local Android

A CPU-only Android chat app for running a compatible GGUF model locally with llama.cpp. The model is **not bundled** in the APK: use the in-app **Pick GGUF** button to select a model from Android's file picker. The selected file is copied into app-private storage and then loaded by the native llama.cpp engine.

## Intended device profile

The first build is tuned for a low-memory ARM64 phone:

- ABI: `arm64-v8a`
- Context: 2048 tokens
- CPU threads: 2
- Max generated tokens: 256
- Temperature: 0.7
- Top-p: 0.8
- CPU inference only
- GGUF model stays outside the APK

For a 4 GB phone, a Q4_K_M model around 650 MB is a sensible starting point, but the phone still needs enough free RAM for Android, the app, model tensors, and KV cache.

## Build entirely on GitHub Actions

No local Android Studio installation is required.

1. Create a GitHub repository.
2. Upload this directory.
3. Push to `main`.
4. Open **Actions → Build Android APK**.
5. Download the `MiniCPM-Local-debug` or `MiniCPM-Local-release` artifact.
6. Install the APK on an ARM64 Android device.
7. Pick a `.gguf` model from Files/Downloads.

The workflow fetches the current upstream llama.cpp source during the build, records the exact commit in `llama-cpp-revision.txt`, and compiles the native Android bridge.

## Model

The app does not download a model automatically. This keeps the APK small and lets you use other compatible GGUF models later. For the original target, use the official MiniCPM5-1B GGUF repository and its Q4_K_M file.

## Native architecture

```text
Android Compose UI
       |
       v
  MainViewModel
       |
       v
  LlamaBridge.kt (JNI)
       |
       v
  llama_jni.cpp
       |
       v
  llama.cpp / ggml CPU
       |
       v
     GGUF
```

## Security / privacy

Inference is local. The app requests no Internet permission and does not upload model files or chat messages. The Android document picker is used so the app can read only the file the user explicitly selects.

## Current limitations

This is the first functional foundation, not a Play Store release. It intentionally keeps the feature set small while establishing the local inference path:

- One loaded model at a time.
- One active chat context.
- No cloud inference.
- No model download manager.
- No release signing key is included.
- No GPU backend yet.

The architecture is deliberately ready for later additions such as saved conversations, model metadata, adjustable context/threads, model deletion, export, and hardware-specific acceleration.

## License notes

llama.cpp is fetched from its upstream repository at build time. Review and comply with the licenses of llama.cpp, ggml, MiniCPM, and any GGUF model you distribute. This repository does not redistribute the model.
