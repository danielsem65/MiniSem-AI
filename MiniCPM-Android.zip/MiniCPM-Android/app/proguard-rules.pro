# JNI entry points are discovered by name.
-keep class com.localminicpm.llama.LlamaBridge { *; }
