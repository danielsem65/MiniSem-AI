#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include "llama.h"
#include "chat.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "MiniCPM", __VA_ARGS__)

static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static std::mutex g_mutex;
static std::atomic<bool> g_stop{false};

static std::string jstr(JNIEnv * env, jstring s) {
    if (!s) return {};
    const char * p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

static void free_model_locked() {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_localminicpm_llama_LlamaBridge_nativeLoadModel(JNIEnv * env, jobject, jstring path, jint threads, jint context) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_model_locked();
    llama_backend_init();

    std::string model_path = jstr(env, path);
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    mp.use_mlock = false;
    g_model = llama_model_load_from_file(model_path.c_str(), mp);
    if (!g_model) return -1;

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(context);
    cp.n_batch = 256;
    cp.n_ubatch = 256;
    cp.n_seq_max = 1;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    cp.no_perf = true;
    cp.offload_kqv = false;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        llama_model_free(g_model);
        g_model = nullptr;
        return -2;
    }
    return 0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localminicpm_llama_LlamaBridge_nativeUnloadModel(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_model_locked();
}

extern "C" JNIEXPORT void JNICALL
Java_com_localminicpm_llama_LlamaBridge_nativeStop(JNIEnv *, jobject) {
    g_stop.store(true);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_localminicpm_llama_LlamaBridge_nativeContextSize(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_ctx ? static_cast<jint>(llama_n_ctx(g_ctx)) : 0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localminicpm_llama_LlamaBridge_nativeChat(JNIEnv * env, jobject, jobjectArray roles, jobjectArray contents, jobject callback, jfloat temperature, jfloat topP, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_stop.store(false);
    if (!g_model || !g_ctx || !callback) return;

    const jsize n = env->GetArrayLength(roles);
    if (n != env->GetArrayLength(contents) || n <= 0) return;

    std::vector<std::string> role_strings;
    std::vector<std::string> content_strings;
    role_strings.reserve(n); content_strings.reserve(n);

    for (jsize i = 0; i < n; ++i) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        auto jc = (jstring) env->GetObjectArrayElement(contents, i);
        role_strings.push_back(jstr(env, jr));
        content_strings.push_back(jstr(env, jc));
        env->DeleteLocalRef(jr); env->DeleteLocalRef(jc);
    }
    common_chat_templates_ptr tmpls = common_chat_templates_init(g_model, "");
    common_chat_templates_inputs chat_inputs;
    chat_inputs.use_jinja = true;
    chat_inputs.enable_thinking = false;
    chat_inputs.add_generation_prompt = true;
    for (jsize i = 0; i < n; ++i) {
        common_chat_msg msg;
        msg.role = role_strings[i];
        msg.content = content_strings[i];
        chat_inputs.messages.push_back(std::move(msg));
    }
    std::string prompt = common_chat_templates_apply(tmpls.get(), chat_inputs).prompt;

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    int n_prompt = llama_tokenize(vocab, prompt.data(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true);
    if (n_prompt < 0) n_prompt = -n_prompt;
    std::vector<llama_token> tokens(static_cast<size_t>(n_prompt));
    if (llama_tokenize(vocab, prompt.data(), static_cast<int32_t>(prompt.size()), tokens.data(), n_prompt, true, true) < 0) return;

    if (static_cast<uint32_t>(tokens.size() + maxTokens) > llama_n_ctx(g_ctx)) {
        int keep = static_cast<int>(llama_n_ctx(g_ctx)) - maxTokens - 8;
        if (keep <= 0) return;
        tokens.erase(tokens.begin(), tokens.begin() + (tokens.size() - keep));
    }

    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return;

    auto sp = llama_sampler_chain_default_params();
    sp.no_perf = true;
    llama_sampler * sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(topP, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onToken = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)V");
    jmethodID onDone = env->GetMethodID(cbClass, "onDone", "()V");
    jmethodID onError = env->GetMethodID(cbClass, "onError", "(Ljava/lang/String;)V");

    for (int i = 0; i < maxTokens && !g_stop.load(); ++i) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;

        char buf[512];
        int32_t len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (len < 0) break;
        jstring piece = env->NewStringUTF(std::string(buf, len).c_str());
        if (onToken) env->CallVoidMethod(callback, onToken, piece);
        env->DeleteLocalRef(piece);
        if (env->ExceptionCheck()) { env->ExceptionClear(); break; }

        batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }

    llama_sampler_free(sampler);
    if (g_stop.load()) {
        if (onDone) env->CallVoidMethod(callback, onDone);
    } else {
        if (onDone) env->CallVoidMethod(callback, onDone);
    }
    env->DeleteLocalRef(cbClass);
}
