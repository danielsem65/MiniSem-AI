package com.localminicpm.llama

object LlamaBridge {
    init { System.loadLibrary("llama_android_bridge") }

    interface Callback {
        fun onToken(token: String)
        fun onDone()
        fun onError(message: String)
    }

    external fun nativeLoadModel(path: String, threads: Int, context: Int): Int
    external fun nativeUnloadModel()
    external fun nativeStop()
    external fun nativeContextSize(): Int
    external fun nativeChat(roles: Array<String>, contents: Array<String>, callback: Callback, temperature: Float, topP: Float, maxTokens: Int)
}
