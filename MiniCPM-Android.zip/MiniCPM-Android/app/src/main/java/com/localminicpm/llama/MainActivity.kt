package com.localminicpm.llama

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ChatMessage(val role: String, val text: String)

class MainViewModel : ViewModel() {
    private lateinit var manager: ModelManager
    var modelReady by mutableStateOf(false); private set
    var modelName by mutableStateOf("No model selected"); private set
    var status by mutableStateOf("Choose a GGUF model to begin."); private set
    var progress by mutableStateOf(0f); private set
    var generating by mutableStateOf(false); private set
    var input by mutableStateOf("")
    val messages = mutableStateListOf<ChatMessage>()
    private var importedFile: java.io.File? = null

    fun attach(context: android.content.Context) {
        if (::manager.isInitialized) return
        manager = ModelManager(context.applicationContext)
        if (manager.modelFile.exists()) {
            importedFile = manager.modelFile
            modelName = "Saved GGUF"
            status = "Loading saved model…"
            viewModelScope.launch(Dispatchers.IO) {
                val result = LlamaBridge.nativeLoadModel(manager.modelFile.absolutePath, 2, 2048)
                withContext(Dispatchers.Main) {
                    if (result == 0) { modelReady = true; status = "Ready • CPU • 2 threads • 2048 context" }
                    else status = "Saved model failed to load (code $result)."
                }
            }
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            status = "Copying model into app storage…"; progress = 0f
            manager.importModel(uri) { done, total ->
                progress = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
            }.onSuccess { file ->
                importedFile = file; modelName = "Selected GGUF"; status = "Model copied. Loading…"
                val result = withContext(Dispatchers.IO) { LlamaBridge.nativeLoadModel(file.absolutePath, 2, 2048) }
                if (result == 0) { modelReady = true; status = "Ready • CPU • 2 threads • 2048 context" }
                else status = "Model load failed (code $result)."
            }.onFailure { status = it.message ?: "Import failed." }
        }
    }

    fun send() {
        val prompt = input.trim(); if (prompt.isEmpty() || !modelReady || generating) return
        input = ""
        messages.add(ChatMessage("user", prompt)); messages.add(ChatMessage("assistant", "")); generating = true; status = "Generating…"
        val roles = messages.dropLast(1).map { it.role }.toTypedArray()
        val contents = messages.dropLast(1).map { it.text }.toTypedArray()
        viewModelScope.launch(Dispatchers.Default) {
            val callback = object : LlamaBridge.Callback {
                override fun onToken(token: String) { viewModelScope.launch(Dispatchers.Main) { val i = messages.lastIndex; messages[i] = messages[i].copy(text = messages[i].text + token) } }
                override fun onDone() { viewModelScope.launch(Dispatchers.Main) { generating = false; status = "Ready" } }
                override fun onError(message: String) { viewModelScope.launch(Dispatchers.Main) { generating = false; status = message } }
            }
            LlamaBridge.nativeChat(roles, contents, callback, 0.7f, 0.8f, 256)
        }
    }

    fun stop() { LlamaBridge.nativeStop(); generating = false; status = "Stopped" }
    fun clearChat() { if (!generating) messages.clear() }

    override fun onCleared() { runCatching { LlamaBridge.nativeUnloadModel() } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiniCpmApp() }
    }
}

@Composable
fun MiniCpmApp(vm: MainViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { vm.attach(context) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::importModel) }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("MiniCPM Local") }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.generating) { Text("Pick GGUF") }
                    OutlinedButton(onClick = vm::clearChat, enabled = vm.modelReady && !vm.generating) { Text("Clear") }
                    if (vm.generating) TextButton(onClick = vm::stop) { Text("Stop") }
                }
                Spacer(Modifier.height(8.dp))
                Text(vm.status, style = MaterialTheme.typography.bodySmall)
                if (vm.progress in 0f..0.999f && !vm.modelReady) { LinearProgressIndicator(progress = { vm.progress }, Modifier.fillMaxWidth().padding(vertical = 8.dp)) }
                Spacer(Modifier.height(8.dp))

                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.messages) { msg ->
                        Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (msg.role == "user") "You" else "MiniCPM", style = MaterialTheme.typography.labelMedium)
                                Spacer(Modifier.height(4.dp)); Text(msg.text)
                            }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = vm.input, onValueChange = { vm.input = it }, modifier = Modifier.weight(1f), enabled = vm.modelReady && !vm.generating, placeholder = { Text("Message…") }, maxLines = 5)
                    Button(onClick = vm::send, enabled = vm.modelReady && !vm.generating && vm.input.isNotBlank()) { Text("Send") }
                }
            }
        }
    }
}
