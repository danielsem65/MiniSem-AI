package com.localminicpm.llama

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ModelManager(private val context: Context) {
    private val modelDir = File(context.filesDir, "models").apply { mkdirs() }
    val modelFile: File get() = File(modelDir, "selected-model.gguf")

    suspend fun importModel(uri: Uri, onProgress: (Long, Long) -> Unit): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val name = queryName(uri) ?: "model.gguf"
            require(name.lowercase().endsWith(".gguf")) { "Please select a .gguf model file." }

            val target = File(modelDir, "selected-model.gguf")
            val temp = File(modelDir, "selected-model.gguf.part")
            val expected = querySize(uri)
            context.contentResolver.openInputStream(uri)?.use { input ->
                temp.outputStream().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var copied = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        onProgress(copied, expected)
                    }
                }
            } ?: error("Could not open the selected file.")

            FileInputValidator.validate(temp)
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Could not finalize model file." }
            target
        }
    }

    private fun queryName(uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }

    private fun querySize(uri: Uri): Long = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
        if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
    } ?: -1L
}

object FileInputValidator {
    fun validate(file: File) {
        file.inputStream().use { input ->
            val magic = ByteArray(4)
            check(input.read(magic) == 4 && magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))) {
                "The selected file is not a valid GGUF file."
            }
        }
    }
}
